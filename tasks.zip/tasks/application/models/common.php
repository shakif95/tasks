<?php

class Common extends CI_Model {


	function get_user($data){
		$this -> db -> from('user');
		$this -> db -> where($data);
		$query = $this -> db -> get();
		return $query = $query->result_array();
	}




	function save_task($data) {

		if ($this -> db -> insert('tasks', $data)) {

			return TRUE;
		}
	}


	function get_tasks() {

		$this -> db -> from('tasks');
		$query = $this -> db -> get();
		return $query = $query->result_array();
	}

	function get_task_by_id($id) {

		//$this -> db -> from('tasks');
		//$this -> db -> where($id);
		//$query = $this -> db -> get();
		$sql = "SELECT * FROM tasks where id=".$id;
		return $query = $this->db->query($sql)->result_array();
		//return $query = $query->result_array();
	}


	function update_task($id,$data){
		$this->db->where('id', $id);
		$this->db->update('tasks', $data);
	}



	function delete_task_by_id($id){
		  $this->db->where('id', $id);
   		  $this->db->delete('tasks');
	}


}
