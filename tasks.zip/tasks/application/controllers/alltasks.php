<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class alltasks extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

		function __construct()
	{
		parent::__construct();
		$this->load->model('common');
		
	}
	
	
	public function index()
	{
			if(!isset($_SESSION['loggedIn'])){
				redirect('home');
			}	



			$data['tasks'] = $this->common->get_tasks();
			
			//var_dump($data); die;
		 
			$data['view'] = "alltasks_view"; 
			$this->load->view('template',$data);
	}

	public function edittask()
	{
			$id = $this->input->get('id',TRUE);		


			$result = $this->common->get_task_by_id($id);
			

				 foreach ($result as $key => $value) {
				 $data = array(
					'id'=> $value['id'], 	
					'name'=> $value['name'], 	
		  			'description'=> $value['description']
				
				);
				}
			
			// var_dump($data); die;
		 
			$data['view'] = "updatetask_view"; 
			$this->load->view('template',$data);
	}


	public function deletetask()
	{
			$id = $this->input->get('id',TRUE);		

			//echo $id; die;

			$this->common->delete_task_by_id($id);
			

			redirect(site_url());
	}

	public function updatetask()
	{
			
		if(isset($_POST['submit'])){
		  $name = $this->input->post('name');
		  $description	= $this->input->post('description');
		  $id = $this->input->post('id');
		  
			
		
		
		  $data = array(
		  			'name'=> $name , 	
		  			'description'=> $description,
					'dateUpdated' => date("y-m-d"),
					 	
			);

			//var_dump($data); die;
			
			$this->common->update_task($id,$data);
				redirect(site_url());
			
			
			
			
		  
		}
	}
	
	
}
//}