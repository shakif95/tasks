<div class="col-md-3">
 
</div>


 <div class="col-md-6">
              
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-gift"></i> Add </h4>
                    </div>
                    <div class="panel-body">
            <form method="POST" action="<?php echo site_url('addtask/savetask')?>">
              <input type="text" placeholder="name" class="form-control" name="name" /> <br />
              <textarea type="desc" placeholder="Description" class="form-control" name="desc" ></textarea>
              <br />
              <input type="submit"  name="submit" value="Add" class="btn btn-success" />              
            </form>
                    </div>
                </div>
            </div>

