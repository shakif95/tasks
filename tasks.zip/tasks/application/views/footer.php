
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                   
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
  

   
</body>

</html>
