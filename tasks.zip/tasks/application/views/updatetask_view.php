<div class="col-md-3">
 
</div>


 <div class="col-md-6">
              
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-gift"></i> Edit </h4>
                    </div>
                    <div class="panel-body">
            <form method="POST" action="<?php echo site_url('alltasks/updatetask')?>">
              <input type="hidden" name="id" value="<?php echo $id ?>" /> <br />
              <input type="text" placeholder="name" class="form-control" name="name" value="<?php echo $name ?>"  /> <br />
              
              <textarea type="text" placeholder="Description" class="form-control" name="description" ><?php echo $description ?></textarea> 
              <br />
              <input type="submit"  name="submit" value="Update" class="btn btn-success" />              
            </form>
                    </div>
                </div>
            </div>
