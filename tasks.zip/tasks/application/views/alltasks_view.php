<div class="container">
  <div class="col-md-3">

  </div>

  <div class="row">
    <div class="col-md-6" style="">
      <table class="table table-hover">
        <thead align="center" style="display: table-header-group">
        <tr>
           <th>No.</th>
           <th>Name</th>
           <th>Description</th>
           <th>Created On</th>
           <th>Last Updated</th>
           <th></th>
           <th></th>
        </tr>
        </thead>
      <tbody>
      <?php 
      $serial = 0;
      foreach ($tasks as $rows){ ?>
        <tr class="item_row">
              <td> <?php echo ++$serial; ?></td>
              <td> <?php echo $rows['name']; ?></td>
              <td> <?php echo $rows['description']; ?></td>
              <td> <?php echo $rows['dateCreated']; ?></td>
              <td> <?php echo $rows['dateUpdated']; ?></td>
              <td><a href="<?php echo site_url('alltasks/edittask?id='.$rows['id'])?>"><span class="glyphicon glyphicon-pencil"></span></a></td>
              <td><a href="<?php echo site_url('alltasks/deletetask?id='.$rows['id'])?>"><span class="glyphicon glyphicon-trash"></span></a></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
    </div>
  </div>
</div>