


function branch_select() {

   branch_id = $("#branch_select").val();
   
    $.ajax({
           type:"POST",
           url : "users/user_by_branch",
           data : {branch : branch_id },
           async: true,
           success : function(response) {              
              $('#client_list').html(response);
           },
           error: function() {
               alert('Error occured');
           }
       });

}

function save_user(){

                
  branch_id = $("#branch_select").val();
   
  
  if(branch_id == ""){
    alert("Please select a branch !!");
    console.log("Please select a branch !!");
    return;
  }


  name = $("#name").val();
  code = $("#code").val();

  if(name !== "" && code != ""){


       $.ajax({
           type:"POST",
           url : "users/save_user",
           data : {branch : branch_id, name : name, code: code },
           async: true,
           success : function(response) {              
              if(response == "ok"){
                ////refreshing the user list
                $("#message").html("User Saved Successfully");
                $("#message").css('color', 'green');
                branch_select();
                resetAddUserForm();
                $("#message").fadeOut(4000);  
               
              }else{
                $("#message").html("Failed to save user. Please try again!!");
                $("#message").css('color', 'red');
                //branch_select();
                resetAddUserForm();
                $("#message").fadeOut(4000);  
              }
           },
           error: function() {
               alert('Error occured');
           }
       });

  }

}
  
  function resetAddUserForm(){
      $("#name").val("");
      $("#code").val("");
      $('#add_user_form').toggle();

  }

  function delete_client(client_id){
  
              //  $("#message").html("User Deleted Successfully"); return;
      if(confirm("Are you sure you want to delete this client from this branch???")){

       $.ajax({
           type:"POST",
           url : "users/delete_user",
           data : {client_id : client_id,},
           async: true,
           success : function(response) {              
              if(response == "ok"){
                ////refreshing the user list
                $("#message").html("User Deleted Successfully");
                $("#message").css('color', 'green');
                branch_select();
                $("#message").fadeOut(4000);  
              }else{
                $("#message").html("Failed to delete user. Please try again!!");
                $("#message").css('color', 'red');
                //branch_select();
                $("#message").fadeOut(4000);  
              }
           },
           error: function() {
               alert('Error occured');
           }
       });


    }
  }


  function edit_client(client_id){

     $.ajax({
           type:"POST",
           url : "users/edit_user",
           data : {client_id : client_id,},
           async: true,
           success : function(response) {              
              
            

           },
           error: function() {
               alert('Error occured');
           }
       });




  }















/*


function flag_it(thread_id,current_flag,thread_comment,url){
	
   
   
   if(thread_comment ==1){
   	
   		comment_id = thread_id;
   	   	id = "#like"+comment_id;
   	   	thumb = "#thumb"+comment_id;
   	   	point = "#points"+ comment_id;
   	   	
   	     //alert(thumb);
	   $.ajax({
	      		
	      type: 'POST',
	      datatype: 'JSON',
	      url: url,
	      data: {
	         current_flag: current_flag,
	         comment_id: comment_id
	      },
	      error: function() {
	         $('#info').html('<p>An error has occurred</p>');
	      },
	      success: function() {
	      	if(current_flag == 1){
	      		
	      		val = parseInt($(thumb).html()) - 1;
	      		$(point).html('Points: '+val*10);
	      		$(id).attr('onClick', "flag_it(" + thread_id + ",0,1,'"+url+"')");
	      		$(thumb).html(val);
	      		
	      	}else{
	      		
	      		val = parseInt($(thumb).html()) + 1;
	      		$(point).html('Points: '+val*10);
	      		$(id).attr('onClick', "flag_it(" + thread_id + ",1,1,'"+url+"')");
	      		$(thumb).html(val);
	      	}
	      },
	   });
	   
   	
   	
   	
   	
   	
   	
   	
   	
   	
   }else{   		 
   id = "#star"+thread_id;
   $.ajax({
      		
      type: 'POST',
      datatype: 'JSON',
      url: url,
      data: {
         current_flag: current_flag,
         thread_id:thread_id
      },
      error: function() {
         $('#info').html('<p>An error has occurred</p>');
      },
      success: function() {
      	if(current_flag == 1){
      		$(id).removeClass('fa-star');
      		$(id).addClass('fa-star-o');	
      		$(id).attr('onClick', "flag_it(" + thread_id + ",0,0,'"+url+"')");
      		
      	}else{
      	
      		$(id).removeClass('fa-star-o');
      		$(id).addClass('fa-star');
      		$(id).attr('onClick', "flag_it(" + thread_id + ",1,0,'"+url+"')");
      	}
      },
   });
   
   }
}
*/